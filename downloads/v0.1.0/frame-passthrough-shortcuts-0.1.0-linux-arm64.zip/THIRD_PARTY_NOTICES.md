# Third-party notices

The application links the following vendored dependencies. Their license
notices accompany source distributions and packaged binaries.

## Compiler support libraries

The ARM64 cross-build uses Zig 0.13.0 and statically links its LLVM C++
support libraries. Their notices are included in `third_party/toolchain-licenses/`:
Zig's MIT license, and the libc++, libc++abi, and libunwind licenses. Source:
[Zig 0.13.0](https://ziglang.org/download/0.13.0/release-notes.html).
Linux builds using GCC link with the GCC Runtime Library Exception.
The Linux C library and SteamVR runtime are loaded from the device, not bundled.

## OpenVR SDK

- Source: [ValveSoftware/openvr](https://github.com/ValveSoftware/openvr/tree/0924064316de3effbcd1acf1e309182a2deb1c05)
- Pinned commit: `0924064316de3effbcd1acf1e309182a2deb1c05`
- Copyright (c) 2015, Valve Corporation. All rights reserved.
- License: BSD 3-Clause. The full notice is included at
  [third_party/openvr/LICENSE](third_party/openvr/LICENSE).
- The portable loader is compiled from source. Valve's runtime is not bundled.

The SDK includes JsonCpp, used by the loader. Its embedded notice offers public
domain or MIT terms; the MIT notice is reproduced below for binary distributions.

## JSON for Modern C++

- Source: [nlohmann/json v3.11.3](https://github.com/nlohmann/json/tree/v3.11.3)
- Copyright (c) 2013-2022 Niels Lohmann.
- License: MIT. The full notice is included at
  [third_party/json/LICENSE.MIT](third_party/json/LICENSE.MIT).

## JsonCpp notice from the OpenVR SDK

```text
Copyright (c) 2007-2010 Baptiste Lepilleur

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use, copy,
modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
